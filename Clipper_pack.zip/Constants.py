TEXTURE_NAMES_LIST = ['Autocorrelation', 'ClusterProminence', 'ClusterShade', 'Contrast', 'Correlation', 'DiffEntropy',
                      'DiffVariance', 'Dissimilarity', 'Energy', 'Entropy', 'Homogeneity', 'Homogeneity2',
                      'InfMeasureCorr1', 'InfMeasureCorr2', 'MaxProb', 'SumAverage', 'SumEntropy', 'SumSquares',
                      'SumVariance']